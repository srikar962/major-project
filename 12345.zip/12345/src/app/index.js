var http=require("http");
var mongoose = require("mongoose");
//var {requestHandler}=require("./request-handler");
const app=require("./server");
mongoose.connect("mongodb://127.0.0.1:27017/Login",{ useNewUrlParser:true});

var server=http.createServer(app);
server.listen(5000,(err)=>{
    if(err){
        console.log("Couldnot start server");
        return;
    }
    console.log("server started in port 5000")
})