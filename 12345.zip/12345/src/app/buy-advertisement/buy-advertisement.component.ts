// import { Component, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder, Validators } from '@angular/forms';
// import { CommonService } from "../common.service";
// import { Router } from '@angular/router';


// @Component({
//   selector: 'app-buy-advertisement',
//   templateUrl: './buy-advertisement.component.html',
//   styleUrls: ['./buy-advertisement.component.css']
// })
// export class BuyAdvertisementComponent implements OnInit {
// storeData; 
// myForm: FormGroup;
//   constructor(private newService:CommonService,private router:Router,private fb: FormBuilder) { 
//     this.myForm = fb.group({
//       username: ['', Validators.required],
//       advertisementName: ['', Validators.required],
//       advertisementPrice:['',Validators.required]
//     })
//   }

//   ngOnInit() {
//     this.newService.GetProduct().subscribe(data => this.storeData = data)
//   }
//   buyAdd(user){
//     var Regex = /^[a-zA-Z.,;\s]+$/
//     var price = this.myForm.get('advertisementPrice').value;
//     var name=this.myForm.get('advertisementName').value;
//     var username=this.myForm.get('username').value;
//     if (this.myForm.valid) {
//       if(price>0 && name.match(Regex) && username.match(Regex) ){
//       alert("you Bought this product")
//       this.newService.saveBuyData(user).subscribe(data=>{alert(data.data);
//         this.ngOnInit();
//         })
//     }
//     else{
//       alert("not valid data")
//     }
//   }
//     else{
//       alert("not valid")
//     }
//   }
//   onCancel(){
//     // this.isUserLoggedIn=false;
//   this.router.navigate(['signin'])
//   // this.newService.logoutUser().subscribe(data=>{alert(data.data);
//   // })
// }
// }
