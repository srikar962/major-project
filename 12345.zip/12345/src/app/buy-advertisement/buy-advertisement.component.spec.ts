import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyAdvertisementComponent } from './buy-advertisement.component';

describe('BuyAdvertisementComponent', () => {
  let component: BuyAdvertisementComponent;
  let fixture: ComponentFixture<BuyAdvertisementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuyAdvertisementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuyAdvertisementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
