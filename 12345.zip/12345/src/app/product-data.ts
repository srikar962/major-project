export class ProductData {
    _id : number;
    productname : string;
    price :number;
    // description:string;
    // empDep:string;
}
