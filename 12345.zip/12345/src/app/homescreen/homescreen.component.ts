import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';
import { Router } from '@angular/router';
import { ProductData } from '../product-data'
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-homescreen',
  templateUrl: './homescreen.component.html',
  styleUrls: ['./homescreen.component.css']
})
export class HomescreenComponent implements OnInit {
  storeData;
flag=true;
myForm: FormGroup;
  constructor( private fb: FormBuilder, private newService: CommonService, private router: Router) {
    this.myForm = fb.group({
      name: ['', Validators.required],
      price: ['', Validators.required]
    })
   }

  ngOnInit() {
    this.newService.GetProduct().subscribe(data => this.storeData = data)
  }
  
  title:String="BUY N SELL ADVERTISEMENT @CAPGEMINI"
  login(){
    console.log(this.storeData)
    this.router.navigate(['login'])
    }
    signup() {
   this.router.navigate(['signup'])
}
}

 