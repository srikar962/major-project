import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';
import { Router } from '@angular/router';
import { ProductData } from '../product-data'
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-loggedin',
  templateUrl: './loggedin.component.html',
  styleUrls: ['./loggedin.component.css']
})
export class LoggedinComponent implements OnInit {
  storeData;
  usn2: string;
  flag = true;
  myForm: FormGroup;
  user
  Repdata;
  valbutton = "Save"
  flag1
  flag123 = true;
  constructor(private fb: FormBuilder, private newService: CommonService, private router: Router) {
    this.myForm = fb.group({
      productname: ['', Validators.required],
      price: ['', Validators.required],
      description: ['', Validators.required],
      name: ['', Validators.required],
      numb: ['', Validators.required],
      email: ['', Validators.required],
      photo: ['', Validators.required],
    })
  }

  ngOnInit() {
    this.newService.GetProduct().subscribe(data => this.storeData = data)
    this.user = localStorage.getItem(this.newService.usn)
    // alert("you logged in " + this.user)
  }

  title: String = "BUY N SELL ADVERTISEMENT @CAPGEMINI"
  addPostClick() {
    console.log(this.storeData)
    this.flag123 = false;
  }
  logoutClick() {
    this.router.navigate([''])
    localStorage.removeItem(this.newService.usn)
    this.usn2 = localStorage.getItem(this.newService.usn)
    // this.newService.logoutUser().subscribe(data=>{alert(data.data);
    // })
  }
  buyProduct(id) {
    confirm("are you confirm to buy this product " + id +"???")
    this.newService.deleteAdd(id).subscribe(data => {
      alert(data.data);
      this.ngOnInit();
    })
  }
  AddPost(user) {
    var Regex = /^[a-zA-Z.,;\s]+$/
    var price = this.myForm.get('price').value;
    var name = this.myForm.get('productname').value;
    var phoneRegex = /^[0-9]{10}$/
    var numb = this.myForm.get('numb').value
    var description = this.myForm.get('description').value;
    if (this.myForm.valid) {
      if (price > 0 && name.match(Regex) && description.match(Regex) && numb.match(phoneRegex)) {
        alert("valid")
        user.mode = this.valbutton;
        this.newService.saveAdd(user).subscribe(data => {alert(data.data);
          this.ngOnInit();
        })
         this.myForm.reset()
       
        // this.router.navigate(['signin'])
       
       
        //         this.router.navigateByUrl('/signin', {skipLocationChange: true}).then(()=>
        // this.router.navigate(["loggedinComponent"]));
      }

      else {
        alert("Given name or price or description pattern is invalid")
      }
    }
    else {
      this.flag1 = false;
      alert("not valid")
    }
    this.flag123 = true;
  }
  onCancel() {
    this.router.navigate(['signin'])
  }
}
